import React, { useState, useEffect, useContext } from "react";
import AuthContext from "../context/AuthContext";

const UnauthorizedPage = () => {
  return <div>אין לך הרשאה לעמוד זה</div>;
};

export default UnauthorizedPage;
