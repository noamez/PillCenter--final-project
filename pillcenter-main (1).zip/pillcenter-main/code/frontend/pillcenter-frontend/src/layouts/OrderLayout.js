import { Outlet } from "react-router-dom";

export default function OrderLayout() {
  return (
    <div>
      <Outlet />
    </div>
  );
}
